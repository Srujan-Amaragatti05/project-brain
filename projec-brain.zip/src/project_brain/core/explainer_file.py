import ast
from pathlib import Path
import os

from project_brain.core.config_loader import load_config
from project_brain.core.logger import log_error
from project_brain.llm.provider import call_llm


def extract_file_structure(source: str):
    functions = []
    classes = []

    try:
        tree = ast.parse(source)
    except Exception:
        return functions, classes

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            functions.append(node.name)
        elif isinstance(node, ast.ClassDef):
            classes.append(node.name)

    return functions, classes


def extract_function(source: str, func_name: str):
    try:
        tree = ast.parse(source)
    except Exception as e:
        log_error(f"Function failed: {str(e)}")
        return None

    lines = source.splitlines()

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == func_name:
            start = node.lineno - 1
            end = getattr(node, "end_lineno", start + 1)
            code = "\n".join(lines[start:end])

            return {
                "name": node.name,
                "args": [arg.arg for arg in node.args.args],
                "line": node.lineno,
                "code": code
            }

    return None


def explain_file(root: Path, file_path: str):
    config = load_config(root)
    provider = config["llm"]["provider"]
    model = config["llm"]["model"]
    api_key = ""

    path = root / file_path
    if not path.exists():
        log_error(f"File not found: {file_path}")
        return "❌ File not found"

    try:
        source = path.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        log_error(f"Unable to read file: {file_path} - {str(e)}")
        return "❌ Unable to read file"

    functions, classes = extract_file_structure(source)

    if provider == "none":
        lines = []
        lines.append(f"File: {file_path}\n")
        lines.append("Summary:")
        lines.append(f"- Functions: {len(functions)}")
        lines.append(f"- Classes: {len(classes)}\n")

        lines.append("Functions:\n")
        for fn in functions:
            lines.append(f"* {fn}")

        return "\n".join(lines)

    prompt = f"""
Explain this file: purpose, main components, data flow, key risks.

{source}
""".strip()

    response = call_llm(provider, model, prompt, api_key)

    return f"File: {file_path}\n\nSummary:\n{response['output'].strip()}"


def explain_function(root: Path, file_path: str, func_name: str):
    config = load_config(root)
    provider = config["llm"]["provider"]
    model = config["llm"]["model"]
    api_key = ""
    include_risks = config.get("explain", {}).get("include_risks", True)

    path = root / file_path
    if not path.exists():
        log_error(f"File not found: {file_path}")
        return "❌ File not found"

    try:
        source = path.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        log_error(f"Unable to read file: {file_path} - {str(e)}")
        return "❌ Unable to read file"

    fn = extract_function(source, func_name)
    if not fn:
        log_error(f"Function not found: {func_name} in {file_path}")
        return "❌ Function not found"

    if provider == "none":
        lines = []
        lines.append(f"Function: {fn['name']}\n")
        lines.append(f"Args: {', '.join(fn['args'])}")
        lines.append(f"Line: {fn['line']}")
        return "\n".join(lines)

    risk_part = ", edge cases, risks" if include_risks else ""

    prompt = f"""
Explain this function: purpose, inputs, outputs, logic{risk_part}.

{fn['code']}
""".strip()

    response = call_llm(provider, model, prompt, api_key)

    return f"Function: {fn['name']}\n\n{response['output'].strip()}"