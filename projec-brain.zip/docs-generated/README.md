# ProjectBrain Documentation

## What Is ProjectBrain
ProjectBrain is an advanced project management and analysis toolkit designed to streamline developer workflows through intelligent command-line integration and automated repository insights.

## Key Capabilities
- Automated project analysis and diagnostic reporting.
- Version-controlled difference explanations and code reviews.
- Seamless project initialization and configuration.
- Comprehensive data export functionalities for code and project changes.
- Integrated LLM testing and validation frameworks.

## Core Workflows
- **Initialization:** Setting up new project environments.
- **Analysis:** Performing deep dives into codebase structures and health.
- **Review:** Iterative checking of diffs and code modifications.
- **Exporting:** Generating project reports and specific file exports for external consumption.
- **Validation:** Running test suites against LLM outputs to ensure consistency.

## Documentation Structure
1. Overview and Philosophy
2. Command Reference
3. Persona Configuration
4. Implementation Use Cases
5. Integration Guidelines

## Command Categories
- **diff**: brain diff show, brain diff review, brain diff explain
- **export**: brain export full-code, brain export file, brain export dir, brain export code-changes
- **project**: brain project init, brain project analyze, brain project summary, brain project doctor
- **testllm**: brain testllm test

## Getting Started
1. Install the CLI tool.
2. Run `brain project init` in your target directory.
3. Utilize `brain project analyze` to generate the initial project state.
4. Explore command categories via the help flags.

## Documentation Statistics
- Commands: 12
- Personas: 7
- Use Cases: 27