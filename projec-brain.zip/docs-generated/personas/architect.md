# Architect

## Who Is This Persona

**Persona:** Architect

**Description:** An expert in system design, repository structure, and high-level software organization.

## Typical Responsibilities

*   **System Analysis:** Evaluating existing codebases for design patterns, technical debt, and architectural integrity.
*   **Structural Oversight:** Ensuring repository organization adheres to best practices and modular design principles.
*   **Documentation:** Generating high-level summaries and comprehensive repository exports for stakeholder review or knowledge transfer.
*   **Optimization:** Identifying bottlenecks in system flow and recommending refactoring paths to improve scalability and maintainability.

## Recommended Approach

1.  **Analyze:** Initiate the process with `brain project analyze` to map dependencies, directory trees, and core architectural components.
2.  **Summarize:** Execute `brain project summary` to distill the technical state, identifying key design patterns and logic distribution.
3.  **Export:** Finalize by using `brain export full-code` to extract a structured representation of the project for documentation or audit purposes.

## Common Scenarios

*   **Onboarding:** Taking over a legacy codebase and needing a rapid architectural map to understand the system structure.
*   **Refactoring:** Planning a transition from a monolithic structure to microservices or modularizing existing code.
*   **Knowledge Transfer:** Exporting a comprehensive project overview to provide documentation for new team members.
*   **Code Audits:** Assessing the health and organization of a project before a major version release or migration.

---

## Overview

Understands system design and repository structure.

## Statistics

- Recommended Commands: 3
- Workflow Steps: 3

## Typical Goals

- Analyze architecture
- Review structure
- Generate repository exports

## Recommended Workflow

1. `brain project analyze`
2. `brain project summary`
3. `brain export full-code`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain export full-code` | Export entire codebase into structured file |
| `brain project analyze` | Analyze repository structure using AST parsing. |
| `brain project summary` | Summarize the analyzed data |

## Related Personas

- Developer
- Reviewer
- Ai Assistant