# Maintainer

## Who Is This Persona

**Persona:** Maintainer

**Description:** Maintains repository health and tooling.

**Goals:**
* Validate environment
* Diagnose problems
* Maintain workflows

**Workflow:**
* `brain project doctor`

**Commands:**
* `brain project init`
* `brain project doctor`
* `brain diff show`

## Typical Responsibilities

* Ensuring all development environments are correctly configured and functional.
* Auditing dependency health and pipeline configurations.
* Troubleshooting build failures or environment inconsistencies.
* Managing repository documentation and automation scripts.
* Reviewing configuration changes to ensure they align with project standards.

## Recommended Approach

* **Proactive Validation:** Execute `brain project doctor` frequently to preemptively identify environmental drift or misconfigurations.
* **Initialization:** Use `brain project init` as the standard onboarding procedure for new contributors to ensure parity.
* **Visibility:** Leverage `brain diff show` during code reviews to verify that proposed changes do not negatively impact core project tooling or automation workflows.
* **Iterative Repair:** Treat maintenance as a continuous loop: diagnose, patch, and verify via automated health checks.

## Common Scenarios

* **New Environment Setup:** Running the initialization sequence to bootstrap a workspace with all necessary dependencies.
* **CI/CD Failure Analysis:** Utilizing diagnostic tools to determine if a build failure is caused by local machine state versus repository-level logic.
* **Dependency Updates:** Monitoring changes via diffs to confirm that dependency upgrades do not break existing automation or script paths.
* **Onboarding Support:** Guiding new developers through the diagnostic process to resolve "it works on my machine" issues.

---

## Overview

Maintains repository health and tooling.

## Statistics

- Recommended Commands: 3
- Workflow Steps: 1

## Typical Goals

- Validate environment
- Diagnose problems
- Maintain workflows

## Recommended Workflow

1. `brain project doctor`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain diff show` | Show semantic git differences between references. |
| `brain project doctor` | Repository diagnostics and environment health checks. |
| `brain project init` | Initialize project-brain in the current directory |

## Related Personas

- Developer
- Reviewer