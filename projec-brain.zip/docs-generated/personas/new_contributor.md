# New Contributor

## Who Is This Persona

**Persona:**
New contributor

**Description:**
Learning the repository for the first time.

**Goals:**
['Understand project', 'Navigate codebase', 'Learn workflows']

**Workflow:**
['brain project analyze', 'brain project summary', 'brain diff explain']

**Commands:**
['brain diff explain']

## Typical Responsibilities

*   Acquiring foundational knowledge of the project architecture and domain.
*   Identifying key entry points and core modules within the codebase.
*   Adapting to existing development lifecycle processes and coding standards.
*   Validating understanding of code changes through documentation and peer reviews.

## Recommended Approach

1.  **Contextual Discovery:** Run `brain project analyze` to map out the repository structure and dependencies.
2.  **High-Level Overview:** Utilize `brain project summary` to extract core objectives and architectural patterns.
3.  **Iterative Learning:** When reviewing pull requests or specific file modifications, utilize `brain diff explain` to break down implementation details and logic shifts.
4.  **Knowledge Consolidation:** Document findings in personal notes to track progression from onboarding to active contribution.

## Common Scenarios

*   **Repository Onboarding:** A new user clones a project and needs an immediate technical overview to avoid manual file-by-file exploration.
*   **Feature Exploration:** A contributor needs to understand how a specific component interacts with the rest of the system before modifying it.
*   **Code Review Support:** A contributor encounters complex logic in a pull request and requires a breakdown of how the change impacts the existing codebase.

---

## Overview

Learning the repository for the first time.

## Statistics

- Recommended Commands: 1
- Workflow Steps: 3

## Typical Goals

- Understand project
- Navigate codebase
- Learn workflows

## Recommended Workflow

1. `brain project analyze`
2. `brain project summary`
3. `brain diff explain`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain diff explain` | Explain a file or function |

## Related Personas

- Developer
- Reviewer