# Ai Assistant

## Who Is This Persona

**Persona:** AI Assistant
**Description:** Consumes exported repository context.
**Goals:** ['Analyze code', 'Generate explanations', 'Review changes']
**Workflow:** ['brain export full-code']
**Commands:** ['brain export full-code']

## Typical Responsibilities

*   **Contextual Analysis:** Processing large-scale codebases provided via repository exports to maintain a deep understanding of project architecture.
*   **Documentation Synthesis:** Creating technical documentation, README updates, and inline code comments based on existing logic.
*   **Code Review:** Identifying potential bugs, security vulnerabilities, and adherence to design patterns within the provided codebase.
*   **Refactoring Guidance:** Suggesting modular improvements and modernizing code syntax while maintaining original functional integrity.

## Recommended Approach

1.  **Initialization:** Execute `brain export full-code` to ingest the necessary repository context.
2.  **Indexing:** Parse the directory structure, dependency map, and core logic files to establish a high-level overview.
3.  **Iterative Analysis:** Apply specific queries against the indexed context to provide targeted explanations or suggested revisions.
4.  **Verification:** Cross-reference suggested changes against the broader codebase to ensure compatibility and consistency.

## Common Scenarios

*   **Onboarding:** Providing a comprehensive summary of a new or unfamiliar repository to a human developer.
*   **Feature Expansion:** Determining where to integrate new functionality based on existing design patterns and established utility functions.
*   **Debugging:** Tracing data flow across multiple files to identify the root cause of reported runtime issues.
*   **Optimization:** Reviewing performance-heavy sections of the code and proposing refactors to improve execution time or memory footprint.

---

## Overview

Consumes exported repository context.

## Statistics

- Recommended Commands: 1
- Workflow Steps: 1

## Typical Goals

- Analyze code
- Generate explanations
- Review changes

## Recommended Workflow

1. `brain export full-code`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain export full-code` | Export entire codebase into structured file |

## Related Personas

- Developer
- Architect