# Developer

## Who Is This Persona

**Persona:** Developer

**Description:** Builds and modifies application code.

## Typical Responsibilities

*   **Implementation:** Translating functional requirements into robust, maintainable source code.
*   **Maintenance:** Debugging existing issues, refactoring technical debt, and optimizing performance.
*   **Documentation:** Ensuring codebases remain understandable through clear implementation patterns and architectural summaries.
*   **Review:** Evaluating code changes to ensure quality, security, and adherence to project standards.

## Recommended Approach

1.  **Contextual Awareness:** Use `brain project analyze` to gain a comprehensive understanding of the current repository structure and dependencies before starting work.
2.  **Iterative Development:** Utilize `brain diff explain` to break down complex changes and `brain diff review` to ensure the logic aligns with project goals.
3.  **Proactive Health:** Run `brain project doctor` periodically to identify configuration issues or environment inconsistencies.
4.  **Information Extraction:** Leverage `brain export full-code` or `brain export file` to manage documentation or share context with team members during collaboration.

## Common Scenarios

*   **Onboarding:** Utilizing `brain project summary` and `brain project analyze` to quickly grasp the architecture of an inherited or new project.
*   **Debugging:** Identifying root causes of production issues by using `brain diff show` to trace recent changes and `brain diff explain` to understand the logic flow.
*   **Quality Assurance:** Running `brain testllm test` to validate code changes against requirements before submitting for final review.
*   **Feature Deployment:** Initiating a new task with `brain project init` and tracking progress through continuous `brain diff` cycles.

---

## Overview

Builds and modifies application code.

## Statistics

- Recommended Commands: 12
- Workflow Steps: 3

## Typical Goals

- Implement features
- Debug issues
- Understand code

## Recommended Workflow

1. `brain project analyze`
2. `brain diff explain`
3. `brain diff review`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain diff explain` | Explain a file or function |
| `brain diff review` | Explain code changes using LLM |
| `brain diff show` | Show semantic git differences between references. |
| `brain export code-changes` | Export changed code between two git references |
| `brain export dir` | Manually add a directory to export |
| `brain export file` | Manually add a single file to export |
| `brain export full-code` | Export entire codebase into structured file |
| `brain project analyze` | Analyze repository structure using AST parsing. |
| `brain project doctor` | Repository diagnostics and environment health checks. |
| `brain project init` | Initialize project-brain in the current directory |
| `brain project summary` | Summarize the analyzed data |
| `brain testllm test` | Test configured LLM provider connectivity. |

## Related Personas

- Reviewer
- Maintainer
- Architect