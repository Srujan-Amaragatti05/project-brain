# Tech Lead

## Who Is This Persona

**Persona:** Tech Lead

**Description:** Leads engineering decisions and reviews.

**Goals:**
* Review implementations
* Guide architecture
* Coordinate development

**Workflow:**
* brain project analyze
* brain diff review
* brain export code-changes

**Commands:**
* brain diff review

## Typical Responsibilities

* Setting technical standards and ensuring code quality across the repository.
* Making high-level architectural decisions and evaluating trade-offs.
* Mentoring junior engineers and facilitating technical growth within the team.
* Resolving blockers and coordinating complex feature implementations.
* Aligning technical output with product requirements and business objectives.

## Recommended Approach

* **Prioritize Maintainability:** Always favor clean, modular, and well-documented code over "quick wins" that introduce technical debt.
* **Continuous Review:** Utilize the `brain diff review` command to maintain oversight on incoming changes, ensuring they adhere to established design patterns.
* **Iterative Analysis:** Regularly use `brain project analyze` to identify bottlenecks, security risks, or legacy code that requires refactoring.
* **Clear Communication:** Provide constructive, actionable feedback during reviews that explains the "why" behind requested changes.

## Common Scenarios

* **Code Review Bottlenecks:** When a team struggles with review turnaround, using `brain diff review` to provide high-level guidance helps unblock the PR process.
* **Architectural Shifts:** When transitioning to a new service pattern, the Tech Lead uses `brain project analyze` to map current dependencies before planning the migration.
* **Onboarding New Features:** Coordinating a large project by breaking it down into actionable tasks and using `brain export code-changes` to manage the transition from design docs to implementation.
* **Resolving Technical Conflicts:** When multiple approaches exist for a problem, the Tech Lead evaluates the trade-offs through analysis and mandates the most sustainable path forward.

---

## Overview

Leads engineering decisions and reviews.

## Statistics

- Recommended Commands: 1
- Workflow Steps: 3

## Typical Goals

- Review implementations
- Guide architecture
- Coordinate development

## Recommended Workflow

1. `brain project analyze`
2. `brain diff review`
3. `brain export code-changes`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain diff review` | Explain code changes using LLM |

## Related Personas

- Developer
- Reviewer