# Reviewer

## Who Is This Persona

**Persona:** reviewer

**Description:** Reviews code changes and pull requests.

**Goals:**
* Review changes
* Identify risks
* Validate modifications

**Workflow:**
* brain diff show
* brain diff review

**Commands:**
* brain project analyze
* brain diff show
* brain diff review
* brain diff explain
* brain export code-changes

## Typical Responsibilities

* Performing comprehensive code inspections to ensure adherence to style guides and architectural standards.
* Assessing the impact of proposed changes on system stability, performance, and security.
* Identifying edge cases, potential bugs, or logical flaws before code integration.
* Providing constructive, actionable feedback to authors to improve code quality and maintainability.
* Verifying that the implementation aligns with the original functional requirements and acceptance criteria.

## Recommended Approach

* **Contextual Analysis:** Begin by using `brain project analyze` to understand the codebase structure and scope before diving into specific changes.
* **Incremental Review:** Use `brain diff show` to isolate specific file modifications, ensuring each part of the commit is understood in context.
* **Security & Logic Focus:** Leverage `brain diff explain` to clarify complex logic or obscure implementations, ensuring no hidden security vulnerabilities or logical regressions are introduced.
* **Structured Feedback:** Utilize `brain diff review` to generate systematic, documented feedback that highlights identified risks and suggestions for optimization.

## Common Scenarios

* **Feature PR Review:** Evaluating a set of new features to ensure they follow project patterns and do not break existing functionality.
* **Bug Fix Validation:** Analyzing patches to verify that the root cause of an issue is addressed without introducing side effects.
* **Refactoring Audits:** Inspecting code restructuring to ensure performance is maintained and complexity is reduced without altering current behavior.
* **Security Hotfix Review:** Prioritizing critical vulnerability patches to confirm the fix is robust and correctly prevents the reported exploit.

---

## Overview

Reviews code changes and pull requests.

## Statistics

- Recommended Commands: 5
- Workflow Steps: 2

## Typical Goals

- Review changes
- Identify risks
- Validate modifications

## Recommended Workflow

1. `brain diff show`
2. `brain diff review`

## Recommended Commands

| Command | Description |
|----------|-------------|
| `brain diff explain` | Explain a file or function |
| `brain diff review` | Explain code changes using LLM |
| `brain diff show` | Show semantic git differences between references. |
| `brain export code-changes` | Export changed code between two git references |
| `brain project analyze` | Analyze repository structure using AST parsing. |

## Related Personas

- Developer
- Maintainer
- Architect